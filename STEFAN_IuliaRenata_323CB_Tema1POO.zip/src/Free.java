
public class Free extends Subscriptie {

	// constructor Free
	public Free(String name) {
		super(name);
	}

	public String getType() {
		return "Free";
	}
}
